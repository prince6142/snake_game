# Flutter_SnakeGame_FlutterWeb
Snake game which runs both on mobile and web using same flutter code.

### If you liked it or if it useful to you in anyway please do click STAR.

## Snake Game Mobile Slow version
![grab-landing-page](https://github.com/sur950/Flutter_SnakeGame_FlutterWeb/blob/master/slow_duration.gif)

## Snake game in Mobile Fast Version
![grab-landing-page](https://github.com/sur950/Flutter_SnakeGame_FlutterWeb/blob/master/speed.gif)

## Snake Game in Flutter Web
![grab-landing-page](https://github.com/sur950/Flutter_SnakeGame_FlutterWeb/blob/master/web.gif)
